UPDATE peliculas SET pel_anio = 2012 WHERE cont_id = 1;
UPDATE usuarios SET usr_celular = 3115678432 WHERE usr_username = "ninja";
DELETE FROM transmisiones WHERE usr_username = "green" AND cont_id = 4;